// 1 task

// let user = {
//     name: prompt("Как вас зовут?"),
//     age: prompt("Сколько вам лет?"),
//     gender: confirm("Вы мужчина? Выберите 'Ок' если да, 'Отмена' если нет") ? "Мужчина" : "Женщина"
// };


// console.log("Имя пользователя:", user.name);
// console.log("Возраст пользователя:", user.age);
// console.log("Пол пользователя:", user.gender);

// alert("Имя: " + user.name + "\nВозрост: " + user.age + "\nПол: " + user.gender);



// 2 task

// let num = prompt();

// if (!isNaN(num)) {
//     alert(num) 
// }else {
//     alert("Вы вели не число!")
// }
// console.log(num);



// Task 3

// let a = +prompt('a?', '');
// console.log(String(a)) // string
// a = +a
// console.log(Number(a)) // number

// switch(a) {
//     case 0:
//         alert( 0 );
//         break;  
//     case 1: 
//         alert( 1 );
//         break;
//     case 2:
//     case 3:
//         alert( '2,3' );
//     default: 
//         undefined;
//         break;
// }



// 4 task

// let sum = 0;

// for (let i = 2; i <= 100; i += 2) {
//   sum += i;
// }

// console.log(sum);
